import scipy.io
import numpy as np
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt

mat = scipy.io.loadmat('data.mat')
data = mat['data']
x = data[:, 0]
y = data[:, 1]


def local_LR(xpred, xtrain, ytrain, h):
    weights = np.exp(-0.5 * ((xtrain - xpred) / h) ** 2)
    xbias = np.c_[np.ones_like(xtrain), xtrain]
    W = np.diag(weights)
    theta = np.linalg.inv(xbias.T @ W @ xbias) @ (xbias.T @ (W @ ytrain))
    xpred_bias = np.array([1, xpred]).reshape(1, -1)
    ypred = xpred_bias @ theta
    return ypred


def cr(x, y, h):
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    cv_errors = []

    for train, val in kf.split(x):
        xtrain, x_val = x[train], x[val]
        ytrain, y_val = y[train], y[val]

        errors = []
        for i in range(len(x_val)):
            ypred = local_LR(x_val[i], xtrain, ytrain, h)
            error = (y_val[i] - ypred) ** 2
            errors.append(error)

        cv_errors.append(np.mean(errors))

    return np.mean(cv_errors)


bandwidths = np.linspace(0.1, 2.0, 20)
cv_scores = []

for h in bandwidths:
    score = cr(x, y, h)
    cv_scores.append(score)
optimal_h = bandwidths[np.argmin(cv_scores)]

# plot
plt.figure()
plt.plot(bandwidths, cv_scores, marker='o')
plt.title('cross validation')
plt.xlabel('bandwidth (h)')
plt.ylabel('cross validation error')
plt.show()

print(f'Optimal bandwidth= {optimal_h}')

xpred = -1.5
ypred = local_LR(xpred, x, y, optimal_h)
print(f'Predicted y for x(-1.5)= {ypred}')

# Plot training data, prediction curve, and prediction marker
plt.figure(figsize=(8, 6))
plt.scatter(x, y, label='Training data')
plt.plot(x, [local_LR(xpred, x, y, optimal_h) for xpred in x], color='red', label='Prediction curve')
plt.scatter(xpred, ypred, color='green', marker='o', label='Prediction')
plt.title('Local linear weighted regression prediction')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.show()
