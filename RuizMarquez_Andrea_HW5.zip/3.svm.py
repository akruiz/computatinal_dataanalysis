from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import OneClassSVM
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

filename = 'spambase.data'
namesfile = 'spambase.names'


def data(filename):
    data = pd.read_csv(filename, header=None)
    return data


def names(filename):
    with open(filename, 'r') as f:
        names = []
        start = False
        for line in f:
            line = line.strip()
            if line and start:
                names.append(line.split(':')[0])
            if line.startswith('1, 0'):
                start = True
    names.append('spam')
    return names


df = data(filename)
df.columns = names(namesfile)
x = df.drop('spam', axis=1)
y = df['spam']

xtrain, X_test, ytrain, ytest = train_test_split(x, y, test_size=0.2, random_state=42)

# decision tree
clf = tree.DecisionTreeClassifier(max_leaf_nodes=12, random_state=42)
clf.fit(x, y)
plt.figure(figsize= (18,10))
tree.plot_tree(clf,fontsize=9, filled=True,  feature_names=df.columns[:-1])
plt.savefig('result.jpg')

tree = tree.DecisionTreeClassifier(random_state=42)
tree.fit(xtrain, ytrain)
tree_accuracy = 1 - tree.score(X_test, ytest)
print('Test error decision tree= ', tree_accuracy)

# random forest
forest = RandomForestClassifier(random_state=0)
forest.fit(xtrain, ytrain)
accuracy = 1 - forest.score(X_test, ytest)
print('Test error random forest= ', accuracy)

# svm
nonspam = xtrain[ytrain == 0]
svmfit = OneClassSVM(kernel='rbf', gamma =.05).fit(nonspam)
ytest_pred = svmfit.predict(X_test)
ytest_pred[ytest_pred == 1] = 0
ytest_pred[ytest_pred == -1] = 1
svm_error = sum(ytest_pred != ytest) / len(ytest)
print('Test error SVM= ', svm_error)

#plot
errors = []
for count in range(1, 100, 5):
    model = RandomForestClassifier(n_estimators=count, random_state=0)
    model.fit(xtrain, ytrain)
    score = 1- model.score(X_test, ytest)
    errors.append([count, score])

errors = np.array(errors)
tree_error = [1 - tree_accuracy] * len(errors)

fig, ax = plt.subplots()
ax.plot(errors[:, 0], errors[:, 1], label='random forest')
ax.plot(errors[:, 0], tree_error, label='CART')
plt.legend()
plt.title('(total misclassification error rate')
plt.xlabel('# of trees')
plt.ylabel('test error')
plt.savefig('error.jpg')

# oob
nu_values = range(1, 20)
oob_errors = []
test_errors = []
for nu in nu_values:
    model = RandomForestClassifier(n_estimators=100, max_features=nu, random_state=0, oob_score=True)
    model.fit(xtrain, ytrain)
    oob_error = 1 - model.oob_score_
    oob_errors.append(oob_error)
    test_error = 1 - model.score(X_test, ytest)
    test_errors.append(test_error)

# Plotting the results
plt.figure(figsize=(10, 6))
plt.plot(nu_values, oob_errors, label='OOB Error')
plt.plot(nu_values, test_errors, label='Test Error')
plt.title('OOB error vs test error (v range)')
plt.legend()
plt.savefig('ooberror.jpg')