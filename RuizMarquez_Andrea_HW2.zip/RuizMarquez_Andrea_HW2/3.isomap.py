import numpy as np
from matplotlib import pyplot as plt
from sklearn.metrics import pairwise_distances
from scipy.sparse.csgraph import shortest_path
from sklearn.decomposition import PCA
import random as rand
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import scipy.io as sio


images = sio.loadmat('isomap.mat', squeeze_me=True)['images'].T

# adjacency matrix
a, n = images.shape
mat = np.zeros(shape=(a, a))
for i in range(a):
    for j in range(a):
        A_i = images[i]
        distance = np.linalg.norm(images[i] - images[j])
        mat[i, j] = distance

plt.imshow(mat)
plt.colorbar()
plt.show()

#  pairwise
D = shortest_path(mat)

# center matrix
I = np.identity(a)
ones = np.ones(shape=(698))
H = I - (1 / a) * np.outer(ones, ones.T)
C = (-1 / 2) * H @ (D ** 2) @ H

#  eigenvalues
U_C, sigc, V_C = np.linalg.svd(C)
dim_1 = U_C[:, 0] * np.sqrt(sigc[0])
dim_2 = U_C[:, 1] * np.sqrt(sigc[1])

# plot
fig1, ax = plt.subplots(figsize=(10, 10))
ax.scatter(dim_1, dim_2)

# add pics
sample = rand.sample(range(a), 40)
for i in sample:
    img = images[i, :].reshape(64, 64).T
    ab = AnnotationBbox(OffsetImage(img), (dim_1[i], dim_2[i]), pad=0.1)
    ax.add_artist(ab)
    ax.scatter(dim_1, dim_2)
fig1.savefig('fig1.png')

# mean iamge
img_mean = np.mean(images,axis = 0)
X_img = (images.T - img_mean[:,None])
U_X,sigx,V_X = np.linalg.svd(X_img)
U_X = U_X.real
sigx = sigx.real
dim_1 = np.dot(U_X[:,0].T,X_img)/np.sqrt(sigx[0])
dim_2 = np.dot(U_X[:,1].T,X_img)/np.sqrt(sigx[1])
fig2, ax = plt.subplots(figsize=(10, 10))
ax.scatter(dim_1,dim_2)
fig2.savefig('fig2.png')


sample = rand.sample(range(a), 40)
for i in sample:
    img = images[i,:].reshape(64, 64).T
    ab = AnnotationBbox(OffsetImage(img), (dim_1[i],dim_2[i]) ,pad=0.1)
    ax.add_artist(ab)
    ax.scatter(dim_1,dim_2)
fig2.savefig('fig3.png')