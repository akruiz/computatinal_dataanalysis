import numpy as np
import glob
from matplotlib import pyplot as plt
from scipy.linalg import svd


def downsample(img, scale=4):
    width = img.shape[1] // 4
    height = img.shape[0] // 4
    resize = np.zeros(shape=(height, width), dtype=np.uint8)

    for i in range(0, img.shape[0] - scale, scale):
        for j in range(0, img.shape[1] - scale, scale):
            resize[i // scale, j // scale] = np.mean(img[i:i + scale, j:j + scale], axis=(0, 1))

    return resize.astype(np.uint8)

def pca_func(X, K=6):
    X = X.T
    mu = np.mean(X, axis=1, keepdims=True)
    X = X - mu
    res, _, _, = svd(X)
    res = res[:, 0:K]
    return res


def plot(W):
    k = W.shape[1]
    fig, axs = plt.subplots(2, 3, figsize=(12, 3), facecolor='w')
    axs = axs.ravel()
    for i in range(k):
        image = W[:, i].reshape((60, 80))
        axs[i].set_title(f'C= {i}')
        axs[i].imshow(image, cmap='gray')
    plt.show()


data = [file for file in glob.glob("yalefaces/*")]

# downsample
pic1 = []
pic2 = []
for file in data:
    image = plt.imread(file)
    new_image = downsample(image).flatten()
    if '1' in file:
        pic1.append(new_image)
    else:
        pic2.append(new_image)

pic1 = np.array(pic1)[:-1]
pic2 = np.array(pic2)[:-1]

# plot & calc faces
res1 = pca_func(pic1)
plot(res1)
res2 = pca_func(pic2)
plot(res2)
