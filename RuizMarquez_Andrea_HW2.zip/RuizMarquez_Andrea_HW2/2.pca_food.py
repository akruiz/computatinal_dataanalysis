import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('food-consumption.csv')

# part a
# set up data, center for pca
country_df = data.drop('Country', axis=1)
center_df = country_df - country_df.mean(axis=0)

# set up covariance matrix
matrix = center_df.cov()

# eigen decomposition scale & sort
eigenvalues, eigenvectors = np.linalg.eig(matrix)
nums = eigenvalues.argsort()[::-1]
eigenvalues = eigenvalues[nums]
eigenvectors = eigenvectors[:, nums]

# first two principal components
pc1 = eigenvectors[:, 0]
pc2 = eigenvectors[:, 1]
pcs = np.dot(center_df, np.vstack((pc1, pc2)).T)

# plot
plt.figure()
plt.scatter(pcs[:, 0], pcs[:, 1])
for i, country in enumerate(data['Country']):
    plt.annotate(country, (pcs[i, 0], pcs[i, 1]),  fontsize=13)

plt.xlabel('principal component 1')
plt.ylabel('principal component 2')
plt.title('PCA: countries by food features')
plt.grid(True)
plt.show()

# part b


# set up data, center for pca
food_df = country_df.T
center_df2 = food_df - food_df.mean(axis=0)

# covariance matrix
cov_matrix2 = center_df2.cov()

# eigen decomposition
eigenvalues2, eigenvectors2 = np.linalg.eig(cov_matrix2)

# sort & get pcs
idx = eigenvalues2.argsort()[::-1]
eigenvalues2 = eigenvalues2[idx]
eigenvectors2 = eigenvectors2[:, idx]
pc11 = eigenvectors2[:, 0]
pc22 = eigenvectors2[:, 1]
pcs2 = np.dot(center_df2, np.vstack((pc11, pc22)).T)

# Plotting
plt.figure()
plt.scatter(pcs2[:, 0], pcs2[:, 1])

# Annotate food items
for i, food in enumerate(data.columns[1:]):
    plt.annotate(food, (pcs2[i, 0], pcs2[i, 1]),  fontsize=12)

plt.xlabel('principal component 1')
plt.ylabel('principal component 2')
plt.title('PCA: foods by country feature')
plt.grid(True)
plt.show()
