import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

data = pd.read_csv("n90pol.csv")
amy = data['amygdala']
acc = data['acc']

#histograms
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
sns.histplot(amy, bins=20, kde=False, color='blue', edgecolor='black')
plt.title('Amygdala')
plt.xlabel('Bins')
plt.ylabel('Frequency')
plt.subplot(1, 2, 2)
sns.histplot(acc, bins=20, kde=False, color='red', edgecolor='black')
plt.title('ACC')
plt.xlabel('Bins')
plt.ylabel('Frequency')
plt.tight_layout()
plt.show()

# kde
h_amy = (4 * np.std(amy) ** 5 / (3 * len(amy))) ** 0.2
h_acc = (4 * np.std(acc) ** 5 / (3 * len(acc))) ** 0.2
kde_amy = gaussian_kde(amy, bw_method=h_amy)
kde_acc = gaussian_kde(acc, bw_method=h_acc)

# plot kde
plt.figure(figsize=(10, 5))
x_vals = np.linspace(amy.min(), amy.max(), 1000)
plt.subplot(1, 2, 1)
plt.plot(x_vals, kde_amy(x_vals), color='blue')
plt.title('Density Amygdala')
plt.xlabel('Volume')
plt.ylabel('Density')

x_vals = np.linspace(acc.min(), acc.max(), 1000)
plt.subplot(1, 2, 2)
plt.plot(x_vals, kde_acc(x_vals), color='red')
plt.title('Density ACC')
plt.xlabel('Volume')
plt.ylabel('Density')
plt.tight_layout()
plt.show()

# 2d
np.random.seed(0)
amygdala_data = np.random.normal(0, 1, 1000)
acc_data = np.random.normal(0, 1, 1000)
bins = 40

plt.hist2d(amygdala_data, acc_data, bins=bins)
plt.xlabel('Amygdala')
plt.ylabel('ACC')
plt.title('2D Histogram of Amygdala and ACC')
plt.colorbar(label='Frequency')
plt.show()

# c) kde
amygdala = data['amygdala']
acc = data['acc']
values = np.vstack([amygdala, acc])
kernel = gaussian_kde(values)
x_min, x_max = amygdala.min(), amygdala.max()
y_min, y_max = acc.min(), acc.max()

x_grid, y_grid = np.mgrid[x_min:x_max:100j, y_min:y_max:100j]
positions = np.vstack([x_grid.ravel(), y_grid.ravel()])
density = np.reshape(kernel(positions).T, x_grid.shape)

plt.figure(figsize=(10, 8))
plt.imshow(np.rot90(density), extent=[x_min, x_max, y_min, y_max])
plt.colorbar(label='Density')
plt.xlabel('Amygdala')
plt.ylabel('ACC')
plt.title('Density Estimation')
plt.show()

# d)
orientation = data['orientation']
amygdala = amygdala[orientation.notnull()]
acc = acc[orientation.notnull()]
orientation = orientation[orientation.notnull()]

# range
ori = [2, 3, 4, 5]

bandwidth = 0.5

# ploy
fig, axs = plt.subplots(2, 2, figsize=(12, 10))

for i, ax in enumerate(axs.flatten()):
    orientation_subset = orientation[orientation == ori[i]]
    amygdala_subset = amygdala[orientation == ori[i]]
    acc_subset = acc[orientation == ori[i]]

    #plot
    kde_amygdala = gaussian_kde(amygdala_subset, bw_method=bandwidth)
    x_amygdala = np.linspace(min(amygdala), max(amygdala), 100)
    ax.plot(x_amygdala, kde_amygdala(x_amygdala), label='Amygdala', color='blue')

    kde_acc = gaussian_kde(acc_subset, bw_method=bandwidth)
    x_acc = np.linspace(min(acc), max(acc), 100)
    ax.plot(x_acc, kde_acc(x_acc), label='ACC', color='red')
    ax.set_title(f'C= {ori[i]}')
    ax.set_xlabel('Volume')
    ax.legend()
plt.tight_layout()
plt.show()

# calc sample means
means = pd.DataFrame(index=['Amygdala', 'ACC'], columns=ori)
for o in ori:
    amygdala_subset = amygdala[orientation == o]
    acc_subset = acc[orientation == o]
    means[o] = [amygdala_subset.mean(), acc_subset.mean()]
print(means)

# data prep e)
data = data[data['orientation'].notna()]

def kde(orientation):
    subset = data[data['orientation'] == orientation]
    x = subset['amygdala']
    y = subset['acc']

    kde = gaussian_kde([x, y], bw_method=bandwidth)

    # Create a grid of points
    x_grid, y_grid = np.mgrid[x.min():x.max():100j, y.min():y.max():100j]
    positions = np.vstack([x_grid.ravel(), y_grid.ravel()])

    # kde calc
    z = np.reshape(kde(positions).T, x_grid.shape)


    plt.figure(figsize=(8, 6))
    sns.heatmap(z, alpha=0.8)
    plt.title(f" C= {orientation}")
    plt.xlabel('Amygdala')
    plt.ylabel('ACC')
    plt.show()

# plot each
orientations = sorted(data['orientation'].unique())
for orientation in orientations:
    kde(orientation)