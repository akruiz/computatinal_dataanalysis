import numpy as np
import scipy.io as spio
from scipy import ndimage
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal as mvn
import seaborn as sns
from sklearn.cluster import KMeans


data = spio.loadmat('data.mat', squeeze_me=True)['data'].T
label = spio.loadmat('label.mat', squeeze_me=True)['trueLabel']
m, n = data.shape
C = np.matmul(data.T, data)/m

# pca the datares
d = 4
V, Sig,_ = np.linalg.svd(C)
V = V[:, :d]

# project the data to the top 4 principal directions
datares = np.dot(data, V)
K = 2
seed = 266

# initialize prior
pi = np.random.random(K)
pi = pi / np.sum(pi)

# initial mean and covariance
mu = np.random.randn(K, d)
mu_old = mu.copy()

sigma = []
for ii in range(K):
    # to ensure the covariance psd
    # np.random.seed(seed)
    dummy = np.random.randn(d, d)
    sigma.append(dummy @ dummy.T)

# initialize the posterior
tau = np.full((m, K), fill_value=0.)
maxIter = 100
tol = 1e-3


# results plot
percent = []
iterations = []
plt.ion()

for ii in range(100):

    # E-step
    for kk in range(K):
        tau[:, kk] = pi[kk] * mvn.pdf(datares, mu[kk], sigma[kk])
    # normalize tau
    sum_tau = np.sum(tau, axis=1)
    sum_tau.shape = (m, 1)
    tau = np.divide(tau, np.tile(sum_tau, (1, K)))

    # M-step
    for kk in range(K):
        # update prior
        pi[kk] = np.sum(tau[:, kk]) / m

        # update component mean
        mu[kk] = datares.T @ tau[:, kk] / np.sum(tau[:, kk], axis=0)

        # update cov matrix
        dummy = datares - np.tile(mu[kk], (m, 1))  # X-mu
        sigma[kk] = dummy.T @ np.diag(tau[:, kk]) @ dummy / np.sum(tau[:, kk], axis=0)

    percent.append(np.sum(np.log(sum_tau)))
    iterations.append(ii)
    print('-----iteration---', ii)
    if np.linalg.norm(mu - mu_old) < tol:
        print('training coverged')
        break
    mu_old = mu.copy()

    if ii == 99:
        print('max iteration reached')
        break

fig=plt.figure()
#fig=plt.xlabel('Iterations')
#fig=plt.ylabel('Likelihood')
#fig=plt.title('Likelihood vs. Iterations')
plt.plot(iterations, percent)
#fig.savefig('plot1.jpg')


# Q2
print(pi)
print(mu)

# mean vector
meanf = V@np.diag(np.sqrt(Sig[:d]))@mu[0]
pic = meanf.reshape(28, 28)
pic = np.fliplr(pic)
pic = ndimage.rotate(pic, 90)

plt.imshow(pic, cmap='gray')
plt.savefig('pic1.jpg')

pic2 = (V@np.diag(np.sqrt(Sig[:d]))@mu[1]).reshape(28, 28)
pic2 = np.fliplr(pic2)
pic2 = ndimage.rotate(pic2, 90)

plt.imshow(pic2, cmap='gray')
plt.savefig('pic2.jpg')


# heatmap
cov1 = sns.heatmap(sigma[0])
heat1 = cov1.get_figure()
heat1.savefig("heat1.jpg")
cov2 = sns.heatmap(sigma[1])
heat2 = cov2.get_figure()
heat2.savefig("heat2.jpg")


# Q3
#gmm
elabel = np.argmax(tau, axis = 1)
elabel[elabel == 0] = 2
elabel[elabel == 1] = 6
print(len(elabel[elabel != label])/len(elabel))

#kmeans
np.random.seed(seed)
kmean = KMeans(n_clusters = 2).fit(data)
kmean.fit(data)
klabel = kmean.labels_
klabel[klabel == 0] = 2
klabel[klabel == 1] = 6
print(len(klabel[klabel != label])/len(klabel))

