import numpy as np
import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.decomposition import PCA
from mlxtend.plotting import plot_decision_regions
import matplotlib.gridspec as gridspec
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression


data = pd.read_csv('marriage.csv')
x = data.iloc[:,0:54]
y = data.iloc[:,54:55]
trainx, testx, trainy, testy = train_test_split(x, y, test_size=0.2, random_state=5248)

trainx = np.array(trainx)
testx = np.array(testx)
trainy = np.array(trainy).reshape(len(trainy)).astype(int)
testy = np.array(testy).reshape(len(testy)).astype(int)

# LR from demo code
lr_model = LogisticRegression(max_iter=200, solver='liblinear')
lr_model.fit(trainx, trainy)
lr_score_train = lr_model.score(trainx, trainy)
lr_score_test = lr_model.score(testx, testy)

print('LR Training Accuracy: ' + str(lr_score_train))
print('Test Accuracy: ' + str(lr_score_test))

# KNN
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(trainx, trainy)
knn_score_train = knn.score(trainx, trainy)
knn_score_test = knn.score(testx, testy)

print('KNN Training Accuracy: ' + str(knn_score_train))
print('Test Accuracy: ' + str(knn_score_test))

# Naive Bayes
naive_bayes = GaussianNB(var_smoothing=0.001)
naive_bayes.fit(trainx, trainy)
nb_score_train = naive_bayes.score(trainx, trainy)
nb_score_test = naive_bayes.score(testx, testy)
print('NB Training Accuracy: ' + str(nb_score_train))
print('Test Accuracy: ' + str(nb_score_test))

# part 2
# PCA
pca = PCA(n_components=2)
pca_data = pca.fit_transform(x)
trainx, testx, trainy, testy = train_test_split(pca_data, y, test_size=0.2, random_state=528)

trainx = np.array(trainx)
testx = np.array(testx)
trainy = np.array(trainy).reshape(len(trainy)).astype(int)
testy = np.array(testy).reshape(len(testy)).astype(int)


lr_model = LogisticRegression(max_iter=200, solver='liblinear')
lr_model.fit(trainx, trainy)
lr_score_train = lr_model.score(trainx, trainy)
lr_score_test = lr_model.score(testx, testy)

print('LR Training Accuracy: ' + str(lr_score_train))
print('Test Accuracy: ' + str(lr_score_test))


knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(trainx, trainy)
knn_score_train = knn.score(trainx, trainy)
knn_score_test = knn.score(testx, testy)

print('KNN Training Accuracy: ' + str(knn_score_train))
print('Test Accuracy: ' + str(knn_score_test))


naive_bayes = GaussianNB()
naive_bayes.fit(trainx, trainy)
nb_score_train = naive_bayes.score(trainx, trainy)
nb_score_test = naive_bayes.score(testx, testy)

print('NB Training Accuracy: ' + str(nb_score_train))
print('Test Accuracy: ' + str(nb_score_test))

x_min, x_max = testx[:, 0].min() - 1, testx[:, 0].max() + 1
y_min, y_max = testx[:, 1].min() - 1, testx[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1),
                     np.arange(y_min, y_max, 0.1))


Z = naive_bayes.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.8)
plt.scatter(testx[:, 0], testx[:, 1], c=testy, edgecolors='k', cmap=plt.cm.Paired)
plt.title('Naive Bayes')
plt.colorbar()
plt.show()

Z = lr_model.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.8)
plt.scatter(testx[:, 0], testx[:, 1], c=testy, edgecolors='k', cmap=plt.cm.Paired)
plt.title('Logistic regression')
plt.colorbar()
plt.show()

Z = knn.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.8)
plt.scatter(testx[:, 0], testx[:, 1], c=testy, edgecolors='k', cmap=plt.cm.Paired)
plt.title('KNN')
plt.colorbar()
plt.show()
